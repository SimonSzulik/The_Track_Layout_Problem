Downloaded from [Graph Layout Benchmark Datasets Repository](https://visdunneright.github.io/gd_benchmark_sets/)

